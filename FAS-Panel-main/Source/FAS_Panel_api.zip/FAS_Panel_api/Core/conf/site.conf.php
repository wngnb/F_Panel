<?php
$cfg['site']['name'] = 'WNG';
$cfg['site']['host'] = '127.0.0.1';
$cfg['site']['keyword'] = '职业社交,技术交流平台,PHP,程序员之家,IT之家';
$cfg['site']['content'] = '职业社交与技术交流平台';
$cfg['site']['seo'] = '_专业的IT职业社交与技术交流平台';
$cfg['site']['stop'] = '0';
$cfg['site']['re'] = '';
$cfg['site']['loation'] = '';